﻿namespace ObjectOrientedPractics.Model
{
    internal class Order
    {
        /// <summary>
        /// Хранит значение количества заказов.
        /// </summary>
        private static int _allOrderCount;

        /// <summary>
        /// Хранит значение идентификатора.
        /// </summary>
        private int _id;

        private int _dateOfOrderCreation;

        private Address _address;

        /// <summary>
        /// Список объектов класса <see cref="Item">.
        /// </summary>
        private List<Item> _items;

    }
}
