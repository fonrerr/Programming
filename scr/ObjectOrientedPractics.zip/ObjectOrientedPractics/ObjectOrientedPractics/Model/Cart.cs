﻿namespace ObjectOrientedPractics.Model
{
    internal class Cart
    {

    }
}
